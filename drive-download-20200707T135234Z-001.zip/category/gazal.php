<html>
<head>
	<title>Gazal Songs</title>
</head>
<class>
<h2 align="left" style="margin-left:50px;">Gazal Songs</h2>
</class>
<class>
<a href="../music/songinfo.php?scode=GZ01&site=Gazal.php">Chai Ghata</a>


</class>


</html>
