<html>
<head>
	<title>Dance Songs</title>
	<style type="text/css">
		body{
  			background:url(http://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dark_wall.png);
		}
		a{
			text-decoration: none;
			color: white;

		}
		a:hover{
			text-decoration: none;
			color: black;
			font-weight: bold;
		}
		div{
			font-family: Arial;
			border: 5px;
			border-color: white;
		}
		table, td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		tr{
			background-color: black; 
		}
		tr:hover{
			letter-spacing: 1px;
			transition: 0.5s;
			background-color: white;
		}
		h2{
			text-align: center;
			color: white;
			font-family: Roboto;
		}
	</style>
</head>
<class>
<h2>Dance Songs</h2>
</class>

<table>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=DA01&site=Dance.php">Baby</a>
		</td>
	</tr>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=DA02&site=Dance.php">Cheez Badi</a>
		</td>
	</tr>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=DA03&site=Dance.php">High Heels</a>
		</td>
	</tr>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=DA04&site=Dance.php">Kukkad</a>
		</td>
	</tr>
</table>




</html>
