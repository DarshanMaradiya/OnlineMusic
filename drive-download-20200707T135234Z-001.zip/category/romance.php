<html>
<head>
	<title>Romance Songs</title>
	<style type="text/css">
		body{
  			background:url(http://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dark_wall.png);
		}
		a{
			text-decoration: none;
			color: white;

		}
		a:hover{
			text-decoration: none;
			color: black;
			font-weight: bold;
		}
		div{
			font-family: Arial;
			border: 5px;
			border-color: white;
		}
		table, td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		tr{
			background-color: black; 
		}
		tr:hover{
			letter-spacing: 1px;
			transition: 0.5s;
			background-color: white;
		}
		h2{
			text-align: center;
			color: white;
			font-family: Roboto;
		}

	</style>
</head>
<class>
<h2>Romance Songs</h2>
</class>

	<table>
		<tr>
			<td>
				<a href="../music/songinfo.php?scode=RM01&site=Romance.php"><div>Koi Tumsa Nahin</div></a>
			</td>
		</tr>
		<tr>
			<td>
				<a href="../music/songinfo.php?scode=RM02&site=Romance.php"><div>Maherbaan</div></a>
			</td>
		</tr>
		<tr>
			<td>
				<a href="../music/songinfo.php?scode=RM03&site=Romance.php"><div>Main Agar Kahoon</div></a>
			</td>
		</tr>
		<tr>
			<td>
				<a href="../music/songinfo.php?scode=RM04&site=Romance.php"><div>Main Hu Hero Tera</div></a>
			</td>
		</tr>
		<tr>	
			<td>
				<a href="../music/songinfo.php?scode=RM05&site=Romance.php"><div>Panchhi Bole</div></a>
			</td>
		</tr>
		<tr>	
			<td>
				<a href="../music/songinfo.php?scode=RM06&site=Romance.php"><div>Sathiya Ye Tune Kya Kiya</div></a>
			</td>
		</tr>
	</table>



</html>
