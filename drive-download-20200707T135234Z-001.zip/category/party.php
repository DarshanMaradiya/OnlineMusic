<html>
<head>
	<title>Party Songs</title>
	<style type="text/css">
		body{
  			background:url(http://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dark_wall.png);
		}
		a{
			text-decoration: none;
			color: white;

		}
		a:hover{
			text-decoration: none;
			color: black;
			font-weight: bold;
		}
		div{
			font-family: Arial;
			border: 5px;
			border-color: white;
		}
		table, td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		tr{
			background-color: black; 
		}
		tr:hover{
			letter-spacing: 1px;
			transition: 0.5s;
			background-color: white;
		}
		h2{
			text-align: center;
			color: white;
			font-family: Roboto;
		}
	</style>
</head>
<class>
<h2 align="left" style="margin-left:50px;">Party Songs</h2>
</class>


<table>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=PT01&site=Party.php">Chaar Botal Vodka</a>
		</td>
	</tr>
	<tr>
		<td>	
			<a href="../music/songinfo.php?scode=PT02&site=Party.php">G Phaad Ke</a>
		</td>
	</tr>
	<tr>
		<td>		
			<a href="../music/songinfo.php?scode=PT03&site=Party.php">Kar Gai Chull</a>
		</td>
	</tr>
	<tr>
		<td>		
			<a href="../music/songinfo.php?scode=PT04&site=Party.php">Tamma Tamma Again</a>
		</td>
	</tr>
	<tr>
		<td>		
			<a href="../music/songinfo.php?scode=PT05&site=Party.php">Vele</a>
		</td>
	</tr>
</table>



</html>
