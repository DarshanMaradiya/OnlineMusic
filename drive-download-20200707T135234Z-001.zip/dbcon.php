<?php
	$con = mysqli_connect('localhost','root','','onlinemusic');
	if($con==false)
	{
		echo 'Connection is not established!';
	}
	/*else
	{	
		echo 'Connection is Okay!';
	}*/
?>
