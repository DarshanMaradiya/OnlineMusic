<html>
<head>
	<title>English Songs</title>
	<style type="text/css">
		body{
  			background:url(http://subtlepatterns2015.subtlepatterns.netdna-cdn.com/patterns/dark_wall.png);
		}
		a{
			text-decoration: none;
			color: white;

		}
		a:hover{
			text-decoration: none;
			color: black;
			font-weight: bold;
		}
		div{
			font-family: Arial;
			border: 5px;
			border-color: white;
		}
		table, td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		td{
			border: 1 px;
			border-style: solid;
			border-collapse: collapse;
			padding: 20px;
			width: 100%;
		}
		tr{
			background-color: black; 
		}
		tr:hover{
			letter-spacing: 1px;
			transition: 0.5s;
			background-color: white;
		}
		h2{
			text-align: center;
			color: white;
			font-family: Roboto;
		}
	</style>
</head>
<class>
<h2>English Songs</h2>
</class>

<table>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=EN01&site=English.php">Common Denominator</a>
		</td>
	</tr>
	<tr>
		<td>
			<a href="../music/songinfo.php?scode=EN02&site=English.php">Despacito</a>
		</td>
	</tr>
	<tr>
		<td>	
			<a href="../music/songinfo.php?scode=EN03&site=English.php">Get Used To It</a>
		</td>
	</tr>
	<tr>
		<td>	
			<a href="../music/songinfo.php?scode=EN04&site=English.php">Sorry</a>
		</td>
	</tr>
	<tr>
		<td>	
			<a href="../music/songinfo.php?scode=EN05&site=English.php">Stuck In The Moment</a>
		</td>
	</tr>
</table>



</html>
